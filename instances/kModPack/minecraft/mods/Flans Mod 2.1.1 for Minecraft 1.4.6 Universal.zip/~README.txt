Flan's Mod 2.1.1 for Minecraft 1.4.6

To install :

CLIENT

Install the most recent recommended MinecraftForge build
(http://www.minecraftforge.net/forum/index.php/board,3.0.html)
Put this zip in the "/.minecraft/mods/" folder.
(You can get to this by going to the Texture Pack Menu in Minecraft, clicking "Show Texture Pack Folder" and then going back a level)

Get some content packs from my mod page
http://www.minecraftforum.net/topic/182918-/

SERVER

Install the most recent recommended MinecraftForge build
(http://www.minecraftforge.net/forum/index.php/board,3.0.html)
Put this zip in "<your server folder>/mods/"

Get some content packs from my mod page
http://www.minecraftforum.net/topic/182918-/

Note : There is currently NO content pack verification between server and client, so you must inform your server users what packs you are using. This feature will be coming soon.